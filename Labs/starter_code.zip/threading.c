#include <threading.h>

void t_init()
{
        // TODO
}

int32_t t_create(fptr foo, int32_t arg1, int32_t arg2)
{
        // TODO
}

int32_t t_yield()
{
        // TODO
}

void t_finish()
{
        // TODO
}
